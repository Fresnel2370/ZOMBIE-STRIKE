package com.zombierstrike3d.lan;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.Window;
import android.view.WindowManager;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private LANServer server;
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        server = new LANServer(getApplicationContext(), 8080);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidLANBridge(), "AndroidLAN");
        web.setBackgroundColor(0x00000000);
        setContentView(web);
        web.loadUrl("file:///android_asset/game.html");
    }

    public class AndroidLANBridge {
        @JavascriptInterface public String startServer() {
            server.start();
            return server.getLocalAddress();
        }
        @JavascriptInterface public String localAddress() { server.start(); return server.getLocalAddress(); }
        @JavascriptInterface public String hostAddress() { return server.getGatewayAddress(); }
        @JavascriptInterface public String wsHostForLocal() { server.start(); return "127.0.0.1:8080"; }
        @JavascriptInterface public String discoverHost() {
            server.start();
            return server.getGatewayAddress();
        }
        @JavascriptInterface public String appVersion() { return "LAN-native-1"; }
    }

    @Override protected void onDestroy() { if (server != null) server.stop(); if (web != null) web.destroy(); super.onDestroy(); }
}

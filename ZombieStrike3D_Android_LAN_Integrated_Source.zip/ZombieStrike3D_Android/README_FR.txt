ZOMBIE STRIKE 3D — APPLICATION ANDROID LAN INTÉGRÉ
====================================================

Cette version transforme le serveur LAN en composant natif de l'application.
L'utilisateur n'a plus à manipuler de fichier .js ni à installer Node.js.

UTILISATION CIBLE
-----------------
1. Un joueur active le point d'accès Wi-Fi de son téléphone.
2. Tous les autres téléphones se connectent à ce point d'accès.
3. Tous ouvrent l'application Zombie Strike 3D.
4. Le joueur qui veut héberger choisit Multijoueur > Créer un salon.
5. Les autres choisissent Multijoueur > Rejoindre et saisissent uniquement le code.
6. L'application détecte automatiquement l'adresse du point d'accès (passerelle Wi-Fi).

ARCHITECTURE
------------
- WebView Android : jeu Three.js existant.
- LANServer.java : serveur HTTP/WebSocket embarqué, sans dépendance externe.
- AndroidLANBridge : démarre le serveur et fournit automatiquement l'adresse LAN.
- Chaque téléphone peut être hôte.
- Aucun serveur Node.js externe n'est nécessaire.

LIMITATION ACTUELLE DU PACK SOURCE
----------------------------------
Le jeu HTML fourni par Claude/V4 importe Three.js depuis jsDelivr. Pour une
application réellement 100 % hors ligne, il faut inclure la copie locale de
Three.js dans assets et remplacer l'import CDN par ./three.module.js.
Le code LAN natif est déjà préparé pour cela.

CONSTRUCTION
------------
Ouvrir ce dossier dans Android Studio avec le SDK Android configuré, puis
Build > Build APK(s).
